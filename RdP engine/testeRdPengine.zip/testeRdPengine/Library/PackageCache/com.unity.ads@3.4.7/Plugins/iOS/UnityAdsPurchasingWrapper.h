typedef void (*UnityAdsPurchasingDidInitiatePurchasingCommandCallback)(const char * eventString);
typedef void (*UnityAdsPurchasingGetProductCatalogCallback)();
typedef void (*UnityAdsPurchasingGetPurchasingVersionCallback)();
typedef void (*UnityAdsPurchasingInitializeCallback)();

void InitializeUnityAdsPurchasingWrapper();
